package com.society;

public class Help {

	int Id,FlatId;
	String SocietyName,UserName,Details,DatePosted,Image;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public int getFlatId() {
		return FlatId;
	}
	public void setFlatId(int flatId) {
		FlatId = flatId;
	}
	public String getSocietyName() {
		return SocietyName;
	}
	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getDetails() {
		return Details;
	}
	public void setDetails(String details) {
		Details = details;
	}
	public String getDatePosted() {
		return DatePosted;
	}
	public void setDatePosted(String datePosted) {
		DatePosted = datePosted;
	}
	public String getImage() {
		return Image;
	}
	public void setImage(String image) {
		Image = image;
	}
	
	
}
