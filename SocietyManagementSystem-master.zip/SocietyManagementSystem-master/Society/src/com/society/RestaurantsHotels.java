package com.society;

public class RestaurantsHotels {
	
	public 	int Id,Contact,Pincode;
	String SocietyName,RHName,Address,City,OpenTime,ClosedTime,OpenDay,ClosedDay;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getSocietyName() {
		return SocietyName;
	}

	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	public String getRHName() {
		return RHName;
	}
	public void setRHName(String rHName) {
		RHName = rHName;
	}
	public int getContact() {
		return Contact;
	}
	public void setContact(int contact) {
		Contact = contact;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public int getPincode() {
		return Pincode;
	}
	public void setPincode(int pincode) {
		Pincode = pincode;
	}
	
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getOpenTime() {
		return OpenTime;
	}
	public void setOpenTime(String openTime) {
		OpenTime = openTime;
	}
	public String getClosedTime() {
		return ClosedTime;
	}
	public void setClosedTime(String closedTime) {
		ClosedTime = closedTime;
	}
	public String getOpenDay() {
		return OpenDay;
	}
	public void setOpenDay(String openDay) {
		OpenDay = openDay;
	}
	public String getClosedDay() {
		return ClosedDay;
	}
	public void setClosedDay(String closedDay) {
		ClosedDay = closedDay;
	}
	
}
	
	
	