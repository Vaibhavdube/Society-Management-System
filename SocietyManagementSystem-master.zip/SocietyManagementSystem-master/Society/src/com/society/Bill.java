package com.society;

public class Bill {

	public int Id, SecurityP, LiftP, WaterP, CleaningP, DiscountP, Monthly, Year;
	float DiscountA;
	String SocietyName;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public int getSecurityP() {
		return SecurityP;
	}
	public void setSecurityP(int securityP) {
		SecurityP = securityP;
	}
	public int getLiftP() {
		return LiftP;
	}
	public void setLiftP(int liftP) {
		LiftP = liftP;
	}
	public int getWaterP() {
		return WaterP;
	}
	public void setWaterP(int waterP) {
		WaterP = waterP;
	}
	public int getCleaningP() {
		return CleaningP;
	}
	public void setCleaningP(int cleaningP) {
		CleaningP = cleaningP;
	}
	public int getDiscountP() {
		return DiscountP;
	}
	public void setDiscountP(int discountP) {
		DiscountP = discountP;
	}
	public int getMonthly() {
		return Monthly;
	}
	public void setMonthly(int monthly) {
		Monthly = monthly;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		Year = year;
	}
	public float getDiscountA() {
		return DiscountA;
	}
	public void setDiscountA(float discountA) {
		DiscountA = discountA;
	}
	public String getSocietyName() {
		return SocietyName;
	}
	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	
	
}
