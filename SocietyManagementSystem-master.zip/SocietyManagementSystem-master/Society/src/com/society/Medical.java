package com.society;

public class Medical {
	
	public 	int Id,Pincode;
	String SocietyName,Contact,Name,Address,City,OpenTime,ClosedTime,OpenDay,ClosedDay;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public int getPincode() {
		return Pincode;
	}
	public void setPincode(int pincode) {
		Pincode = pincode;
	}
	public String getSocietyName() {
		return SocietyName;
	}
	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getOpenTime() {
		return OpenTime;
	}
	public void setOpenTime(String openTime) {
		OpenTime = openTime;
	}
	public String getClosedTime() {
		return ClosedTime;
	}
	public void setClosedTime(String closedTime) {
		ClosedTime = closedTime;
	}
	public String getOpenDay() {
		return OpenDay;
	}
	public void setOpenDay(String openDay) {
		OpenDay = openDay;
	}
	public String getClosedDay() {
		return ClosedDay;
	}
	public void setClosedDay(String closedDay) {
		ClosedDay = closedDay;
	}

	
}
	
	
	