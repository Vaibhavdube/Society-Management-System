package com.society;

public class Results {
	public static final String SUCCESS="success";
	public static final String FAILURE="failure";
	public static final String PROBLEM="problem";

}
