package com.society;

public class ATM {
	
	public 	int Id,KM;
	String SocietyName,ATMName,Location;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getSocietyName() {
		return SocietyName;
	}

	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	public String getATMName() {
		return ATMName;
	}
	public void setATMName(String aTMName) {
		ATMName = aTMName;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public int getKM() {
		return KM;
	}
	public void setKM(int kM) {
		KM = kM;
	}
}
	
	
	
	
	
	
	
	
	
	