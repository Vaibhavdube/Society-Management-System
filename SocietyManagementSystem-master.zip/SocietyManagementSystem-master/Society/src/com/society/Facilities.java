package com.society;

public class Facilities {
	
	int Id,BookingId;
	String SocietyName,Booking,Details,DateOfBooking,DateBook,StartTime,EndTime;
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public int getBookingId() {
		return BookingId;
	}
	public void setBookingId(int bookingId) {
		BookingId = bookingId;
	}
	public String getSocietyName() {
		return SocietyName;
	}
	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	public String getBooking() {
		return Booking;
	}
	public void setBooking(String booking) {
		Booking = booking;
	}
	public String getDetails() {
		return Details;
	}
	public void setDetails(String details) {
		Details = details;
	}
	public String getDateOfBooking() {
		return DateOfBooking;
	}
	public void setDateOfBooking(String dateOfBooking) {
		DateOfBooking = dateOfBooking;
	}
	public String getDateBook() {
		return DateBook;
	}
	public void setDateBook(String dateBook) {
		DateBook = dateBook;
	}
	public String getStartTime() {
		return StartTime;
	}
	public void setStartTime(String startTime) {
		StartTime = startTime;
	}
	public String getEndTime() {
		return EndTime;
	}
	public void setEndTime(String endTime) {
		EndTime = endTime;
	}
	
}
	
	
