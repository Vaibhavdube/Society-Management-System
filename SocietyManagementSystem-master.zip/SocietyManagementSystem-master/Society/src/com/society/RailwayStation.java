package com.society;

public class RailwayStation {
	
	public 	int Id,KM;
	String SocietyName,Name,Location;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getSocietyName() {
		return SocietyName;
	}

	public void setSocietyName(String societyName) {
		SocietyName = societyName;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public int getKM() {
		return KM;
	}
	public void setKM(int kM) {
		KM = kM;
	}
}
	
	
	
	
	
	
	
	
	
	