# SocietryManagementSystem
Society Management System
# Description:
Society Management projects. This software is for society administrators, members.
It provides transparency between society management and their members. 
It generates bill receipts, all reports required for members and management.
# Technology: 
Java EE, JSP.
# Frameworks:
Hibernate.
# Tools: 
MySql-Front, Eclipes IDE.
